"""
XSS TRAINING LAB — intentionally vulnerable web app for learning purposes.

RUN LOCALLY ONLY. Do not deploy this to any public server or network.
Everything (the "attacker" cookie collector included) runs on localhost
so no third party or real user is ever involved.

Start it with:
    pip install flask --break-system-packages   (if needed)
    python3 app.py
Then open http://127.0.0.1:5000/

Routes:
  /search            -> REFLECTED XSS (vulnerable)
  /search-safe       -> same feature, fixed, for comparison
  /guestbook         -> STORED XSS (vulnerable)
  /guestbook-safe    -> same feature, fixed, for comparison
  /collector         -> fake "attacker" endpoint that logs cookies sent to it,
                         so you can see stolen-cookie exfiltration end-to-end
                         without ever touching a real external server
  /collector/log     -> view what the collector has received
  /reset             -> wipe the guestbook + collector log
"""
from flask import Flask, request, render_template, redirect, url_for, make_response
from markupsafe import escape
import sqlite3, time, os

app = Flask(__name__)
DB = os.path.join(os.path.dirname(__file__), "lab.db")


def db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = db()
    conn.execute("""CREATE TABLE IF NOT EXISTS comments
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      author TEXT, body TEXT, ts REAL)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS collector_log
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      data TEXT, ts REAL)""")
    conn.commit()
    conn.close()


@app.route("/")
def home():
    return render_template("home.html")


# ---------------------------------------------------------------------------
# 1) REFLECTED XSS — vulnerable version
# ---------------------------------------------------------------------------
# The query is echoed straight into the HTML response with NO output
# encoding. Whatever the browser is told to render, it renders — including
# <script> tags or event-handler attributes supplied by the attacker.
#
# A session cookie is set (deliberately NOT HttpOnly) purely so this lab can
# demonstrate document.cookie theft. In a real app, session cookies should
# always be HttpOnly, which alone would defeat this exact exfiltration
# technique (though not all XSS impact).
@app.route("/search")
def search_vulnerable():
    q = request.args.get("q", "")
    # VULNERABLE: q is inserted into the page unescaped via |safe in the template
    resp = make_response(render_template("search_vulnerable.html", q=q))
    if not request.cookies.get("session_id"):
        resp.set_cookie("session_id", "demo-session-12345", httponly=False)
    return resp


# 1b) Fixed version — Jinja2 autoescapes by default, so simply NOT marking
# the value |safe is most of the fix. We also show it explicitly with escape().
@app.route("/search-safe")
def search_safe():
    q = request.args.get("q", "")
    return render_template("search_safe.html", q=escape(q))


# ---------------------------------------------------------------------------
# 2) STORED XSS — vulnerable version
# ---------------------------------------------------------------------------
# Guestbook entries are saved verbatim and re-rendered unescaped for EVERY
# visitor who loads the page afterward — that's what makes stored XSS more
# dangerous than reflected: no victim-specific link needs to be delivered,
# the payload just sits there and fires on anyone who views it.
@app.route("/guestbook", methods=["GET", "POST"])
def guestbook_vulnerable():
    if request.method == "POST":
        author = request.form.get("author", "anon")
        body = request.form.get("body", "")
        conn = db()
        conn.execute("INSERT INTO comments (author, body, ts) VALUES (?,?,?)",
                     (author, body, time.time()))
        conn.commit()
        conn.close()
        return redirect(url_for("guestbook_vulnerable"))
    conn = db()
    rows = conn.execute("SELECT * FROM comments ORDER BY id DESC").fetchall()
    conn.close()
    resp = make_response(render_template("guestbook_vulnerable.html", comments=rows))
    if not request.cookies.get("session_id"):
        resp.set_cookie("session_id", "demo-session-12345", httponly=False)
    return resp


# 2b) Fixed version — escape on output, plus a Content-Security-Policy header
# as defense in depth (even if an encoding bug slipped through, CSP blocks
# inline script execution and outbound fetches to unapproved hosts).
@app.route("/guestbook-safe", methods=["GET", "POST"])
def guestbook_safe():
    if request.method == "POST":
        author = request.form.get("author", "anon")
        body = request.form.get("body", "")
        conn = db()
        conn.execute("INSERT INTO comments (author, body, ts) VALUES (?,?,?)",
                     (author, body, time.time()))
        conn.commit()
        conn.close()
        return redirect(url_for("guestbook_safe"))
    conn = db()
    rows = conn.execute("SELECT * FROM comments ORDER BY id DESC").fetchall()
    conn.close()
    resp = make_response(render_template("guestbook_safe.html", comments=rows))
    resp.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'"
    return resp


# ---------------------------------------------------------------------------
# 3) Local "attacker" collector — stands in for Burp Collaborator / a remote
#    listener, entirely on localhost, so the exfiltration demo is self-
#    contained and never touches a real third party.
# ---------------------------------------------------------------------------
@app.route("/collector", methods=["GET"])
def collector():
    data = request.args.get("data", "")
    conn = db()
    conn.execute("INSERT INTO collector_log (data, ts) VALUES (?,?)", (data, time.time()))
    conn.commit()
    conn.close()
    return "", 204


@app.route("/collector/log")
def collector_log():
    conn = db()
    rows = conn.execute("SELECT * FROM collector_log ORDER BY id DESC").fetchall()
    conn.close()
    return render_template("collector_log.html", rows=rows)


@app.route("/reset")
def reset():
    conn = db()
    conn.execute("DELETE FROM comments")
    conn.execute("DELETE FROM collector_log")
    conn.commit()
    conn.close()
    return redirect(url_for("home"))


if __name__ == "__main__":
    init_db()
    app.run(host="127.0.0.1", port=5000, debug=True)
